import { cores as CORE_TABLE, requiresThreads } from "../data/src/consts.js";
import { SYSTEMS, PATCH_EXTENSIONS, extensionOf, labelFor, classifyFiles, detectSystem } from "./detect.js";
import * as library from "./library.js";
import { exportBackup, importBackup } from "./backup.js";

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const flag = (name) => params.get(name) === "1" || params.get(name) === "true";
const OPTIONS_KEY = "ejs-launcher-options";

let manifest = null;
let available = SYSTEMS;
let busy = false;

// ---------- banners ----------
function banner(text, kind, actions) {
    const box = document.createElement("div");
    box.className = "banner" + (kind ? " " + kind : "");
    const span = document.createElement("span");
    span.textContent = text;
    box.appendChild(span);
    const close = () => box.remove();
    for (const [label, fn] of actions || [["Dismiss", null]]) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = label;
        button.addEventListener("click", () => {
            close();
            if (fn) fn();
        });
        box.appendChild(button);
    }
    $("banners").appendChild(box);
    return close;
}

// ---------- cores ----------
const coresFor = (system) => CORE_TABLE[system] || [system];

function hasLocalCore(core) {
    if (!manifest) return true;
    const prefix = core + "-";
    return Object.keys(manifest.files).some((name) => name.startsWith(prefix) && /^(thread-)?(legacy-)?wasm\.7z$/.test(name.slice(prefix.length)));
}
const isAvailable = (system) => coresFor(system).some(hasLocalCore);
const needsThreads = (system) => coresFor(system).some((c) => requiresThreads.includes(c));

async function loadManifest() {
    try {
        const response = await fetch("data/cores/manifest.json", { cache: "no-cache" });
        if (!response.ok) throw new Error("HTTP " + response.status);
        manifest = await response.json();
        window.EJS_coreManifest = manifest;
    } catch (e) {
        manifest = null;
    }
}

function populateSystems() {
    available = SYSTEMS.filter(([id]) => isAvailable(id));
    const select = $("system");
    for (const [id, label] of available) {
        const option = document.createElement("option");
        option.value = id;
        option.textContent = label + (needsThreads(id) && !window.crossOriginIsolated ? " (needs threads)" : "");
        select.appendChild(option);
    }
    $("status").textContent = manifest
        ? `${available.length} systems ready (${Object.keys(manifest.cores).length} cores)`
        : "No core manifest found. Copy the *.7z cores into data/cores/ and run: node tools/generate-core-manifest.mjs";
}

// ---------- options ----------
function restoreOptions() {
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem(OPTIONS_KEY) || "{}"); } catch (e) { /* ignore */ }
    for (const input of document.querySelectorAll("[data-remember]")) {
        if (typeof saved[input.id] === "boolean") input.checked = saved[input.id];
        input.addEventListener("change", saveOptions);
    }
    if (saved.mode !== undefined) {
        const radio = document.querySelector(`input[name=mode][value="${saved.mode}"]`);
        if (radio) radio.checked = true;
    }
    for (const radio of document.querySelectorAll("input[name=mode]")) radio.addEventListener("change", saveOptions);

    // URL parameters win over remembered options
    if (params.has("debug")) $("debug").checked = flag("debug");
    if (params.has("threads")) $("threads").checked = flag("threads");
    if (params.get("cache") === "0" || params.get("cache") === "false") $("cache").checked = false;
    const mode = params.get("browserMode");
    if (mode) {
        const value = mode === "1" ? "mobile" : mode === "2" ? "desktop" : mode;
        const radio = document.querySelector(`input[name=mode][value="${value}"]`);
        if (radio) radio.checked = true;
    }
    if (flag("debug") || flag("threads")) $("advanced").open = true;
}
function saveOptions() {
    const options = {};
    for (const input of document.querySelectorAll("[data-remember]")) options[input.id] = input.checked;
    const mode = document.querySelector("input[name=mode]:checked");
    options.mode = mode ? mode.value : "";
    try { localStorage.setItem(OPTIONS_KEY, JSON.stringify(options)); } catch (e) { /* ignore */ }
}

// ---------- system choice ----------
function pickSystem(fileName, candidates) {
    const ext = extensionOf(fileName);
    const list = candidates.length ? candidates : available.map(([id]) => id);
    $("pickerText").textContent = candidates.length
        ? `Several systems use .${ext} files. Which one is "${fileName}" for?`
        : `Unknown file type${ext ? " ." + ext : ""}. Which system is "${fileName}" for?`;
    const box = $("pickerButtons");
    box.textContent = "";
    $("picker").hidden = false;
    $("picker").scrollIntoView({ block: "nearest" });
    return new Promise((resolve) => {
        for (const id of list) {
            const button = document.createElement("button");
            button.type = "button";
            button.textContent = labelFor(id);
            button.addEventListener("click", () => {
                if ($("rememberPick").checked && ext) {
                    try { localStorage.setItem("ejs-system-" + ext, id); } catch (e) { /* ignore */ }
                }
                $("picker").hidden = true;
                resolve(id);
            });
            box.appendChild(button);
        }
        const cancel = document.createElement("button");
        cancel.type = "button";
        cancel.textContent = "Cancel";
        cancel.addEventListener("click", () => {
            $("picker").hidden = true;
            resolve(null);
        });
        box.appendChild(cancel);
        box.firstChild.focus();
    });
}

async function chooseSystem(rom, fileName) {
    const forced = $("system").value || params.get("core");
    if (forced) return forced;
    let file = rom;
    if (!(rom instanceof Blob)) {
        // URL ROM: only fetch when the extension alone is not enough
        const quick = available.filter(([, , exts]) => exts.includes(extensionOf(fileName)));
        if (quick.length === 1) return quick[0][0];
        try { file = new File([await (await fetch(rom)).blob()], fileName); } catch (e) { file = null; }
    }
    if (file) {
        const { system, candidates } = await detectSystem(file, available);
        if (system) return system;
        const remembered = localStorage.getItem("ejs-system-" + extensionOf(fileName));
        if (remembered && available.some(([id]) => id === remembered)) return remembered;
        return pickSystem(fileName, candidates);
    }
    return pickSystem(fileName, []);
}

// ---------- launch ----------
function currentMode() {
    const checked = document.querySelector("input[name=mode]:checked");
    return (checked && checked.value) || undefined;
}

function launch({ rom, name, system, bios, patch }) {
    const threads = ($("threads").checked || needsThreads(system)) && !!window.SharedArrayBuffer;
    const options = { debug: $("debug").checked, cache: $("cache").checked, mode: currentMode() };
    const gameName = name.replace(/\.[^.]*$/, "");

    // RetroArch applies a patch automatically when it sits next to the ROM with the same base name
    let patchFile = "";
    if (patch) patchFile = new File([patch], gameName + "." + extensionOf(patch.name));

    const display = document.createElement("div");
    const game = document.createElement("div");
    display.id = "display";
    game.id = "game";
    display.appendChild(game);
    $("menu").remove();
    document.body.classList.add("playing");
    document.body.appendChild(display);

    window.EJS_player = "#game";
    window.EJS_gameName = gameName;
    window.EJS_gameUrl = rom;
    window.EJS_biosUrl = bios || "";
    window.EJS_gamePatchUrl = patchFile;
    window.EJS_core = system;
    window.EJS_pathtodata = "data/";
    window.EJS_startOnLoaded = true;
    window.EJS_DEBUG_XX = options.debug;
    window.EJS_threads = threads;
    window.EJS_cacheConfig = { enabled: options.cache, cacheMaxSizeMB: 4096, cacheMaxAgeMins: 7200 };
    window.EJS_askBeforeExit = false;
    if (options.mode) window.EJS_browserMode = options.mode;
    if (params.get("lang")) window.EJS_language = params.get("lang");
    const backToMenu = () => { location.href = location.pathname; };
    window.EJS_onExit = backToMenu;
    window.EJS_onBackToMenu = backToMenu;

    const script = document.createElement("script");
    script.src = "data/loader.js";
    document.body.appendChild(script);
}

async function start({ files, rom, name, system }) {
    if (busy) return;
    busy = true;
    try {
        let bios = $("bios").files[0] || null;
        let patch = $("patch").files[0] || null;
        if (files) {
            const sorted = classifyFiles(files);
            if (!sorted.rom) {
                banner("Drop a ROM file (a patch or BIOS alone can't be played).", "warn");
                return;
            }
            rom = sorted.rom;
            name = rom.name;
            bios = sorted.bios || bios;
            patch = sorted.patch || patch;
        }
        if (PATCH_EXTENSIONS.includes(extensionOf(name))) {
            banner("That is a patch file. Drop it together with the ROM it belongs to.", "warn");
            return;
        }
        system = system || await chooseSystem(rom, name);
        if (!system) return;
        if (needsThreads(system) && !window.SharedArrayBuffer) {
            banner(labelFor(system) + " needs threads, which this browser has not enabled yet. Reload the page once and try again.", "warn");
            return;
        }
        if ($("library").checked) await library.remember({ rom, name, system }).catch(() => {});
        launch({ rom, name, system, bios, patch });
    } finally {
        busy = false;
    }
}

// ---------- recent games ----------
function renderRecent() {
    const list = library.listRecent();
    $("recentSection").hidden = list.length === 0;
    const ul = $("recent");
    ul.textContent = "";
    for (const entry of list) {
        const li = document.createElement("li");
        const info = document.createElement("div");
        info.className = "info";
        const title = document.createElement("div");
        title.className = "name";
        title.textContent = entry.name;
        title.title = entry.name;
        const sub = document.createElement("div");
        sub.className = "sub";
        const played = library.formatPlaytime(library.playtimeFor(entry.name.replace(/\.[^.]*$/, "")));
        sub.textContent = [labelFor(entry.system), library.timeAgo(entry.lastPlayed), played].filter(Boolean).join(" · ");
        info.append(title, sub);

        const play = document.createElement("button");
        play.type = "button";
        play.className = "play";
        play.textContent = "Play";
        play.addEventListener("click", async () => {
            const rom = await library.open(entry);
            if (!rom) {
                banner(`"${entry.name}" is no longer stored. Drop the file again.`, "warn");
                await library.forget(entry.id);
                renderRecent();
                return;
            }
            start({ rom, name: entry.name, system: available.some(([id]) => id === entry.system) ? entry.system : null });
        });
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "remove";
        remove.textContent = "✕";
        remove.title = "Remove from recent games";
        remove.setAttribute("aria-label", "Remove " + entry.name);
        remove.addEventListener("click", async () => {
            await library.forget(entry.id);
            renderRecent();
        });
        li.append(info, play, remove);
        ul.appendChild(li);
    }
}

// ---------- storage, backup ----------
const mb = (bytes) => (bytes / 1048576).toFixed(bytes > 10485760 ? 0 : 1) + " MB";
async function showStorage() {
    if (!navigator.storage || !navigator.storage.estimate) {
        $("storageInfo").textContent = "Storage: unknown";
        return;
    }
    const { usage, quota } = await navigator.storage.estimate();
    const persisted = navigator.storage.persisted ? await navigator.storage.persisted() : false;
    $("storageInfo").textContent = `Storage: ${mb(usage || 0)} of ${mb(quota || 0)}${persisted ? " (protected)" : ""}`;
}
async function clearCache() {
    if (!confirm("Remove downloaded cores and cached games? Saves, save states and recent games are kept.")) return;
    if (window.caches) {
        for (const name of await caches.keys()) if (name.startsWith("ejs-local-")) await caches.delete(name);
    }
    await new Promise((resolve) => {
        const request = indexedDB.deleteDatabase("EmulatorJS-Cache");
        request.onsuccess = request.onerror = request.onblocked = () => resolve();
    });
    banner("Download cache cleared.");
    showStorage();
}
async function doExport() {
    try {
        const { blob, records } = await exportBackup();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "emulatorjs-saves-" + new Date().toISOString().slice(0, 10) + ".json";
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 2000);
        banner(`Backup exported (${records} saved items).`);
    } catch (e) {
        banner("Export failed: " + e.message, "error");
    }
}
async function doImport(file) {
    try {
        const records = await importBackup(file);
        banner(`Backup restored (${records} saved items).`);
        showStorage();
    } catch (e) {
        banner("Import failed: " + e.message, "error");
    }
}

// ---------- environment ----------
function checkCapabilities() {
    if (typeof WebAssembly !== "object") {
        banner("This browser cannot run the emulator (WebAssembly is unavailable).", "error", []);
        return false;
    }
    const canvas = document.createElement("canvas");
    if (!canvas.getContext("webgl2") && !canvas.getContext("webgl")) {
        banner("WebGL is unavailable. Most systems will fail to start; check that hardware acceleration is on.", "warn");
    }
    if (!window.isSecureContext) {
        banner("Open this page over https or localhost to enable offline play, threads and install.", "warn");
    }
    return true;
}

function setupServiceWorker() {
    const note = $("threadsNote");
    if (!("serviceWorker" in navigator) || !window.isSecureContext) {
        $("threads").disabled = true;
        note.textContent = "needs https or localhost";
        return Promise.resolve();
    }
    const wasControlled = !!navigator.serviceWorker.controller;
    note.textContent = window.crossOriginIsolated ? "available" : "enabling…";
    return new Promise((resolve) => {
        navigator.serviceWorker.register("sw.js").then((registration) => {
            // A newer sw.js was published: offer a reload instead of switching mid-session
            registration.addEventListener("updatefound", () => {
                const worker = registration.installing;
                if (!wasControlled || !worker) return;
                worker.addEventListener("statechange", () => {
                    if (worker.state === "activated") {
                        banner("A new version is available.", "", [["Reload", () => location.reload()], ["Later", null]]);
                    }
                });
            });
            return navigator.serviceWorker.ready;
        }).then(() => {
            if (window.crossOriginIsolated) {
                resolve();
                return;
            }
            if (navigator.serviceWorker.controller) {
                $("threads").disabled = true;
                note.textContent = "not supported by this browser";
                resolve();
                return;
            }
            if (sessionStorage.getItem("ejs-coi-reload")) {
                resolve();
                return;
            }
            // First visit: reload once so the worker can add the isolation headers
            sessionStorage.setItem("ejs-coi-reload", "1");
            navigator.serviceWorker.addEventListener("controllerchange", () => location.reload());
            setTimeout(resolve, 3000);
        }).catch(() => {
            $("threads").disabled = true;
            note.textContent = "unavailable";
            resolve();
        });
    });
}

function wireInputs() {
    $("rom").addEventListener("change", (event) => {
        const files = Array.from(event.target.files);
        event.target.value = "";
        if (files.length) start({ files });
    });
    $("drop").addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            $("rom").click();
        }
    });
    const drop = $("drop");
    for (const type of ["dragenter", "dragover"]) {
        window.addEventListener(type, (event) => {
            event.preventDefault();
            drop.classList.add("over");
        });
    }
    window.addEventListener("dragleave", (event) => {
        if (!event.relatedTarget) drop.classList.remove("over");
    });
    window.addEventListener("drop", (event) => {
        event.preventDefault();
        drop.classList.remove("over");
        const files = Array.from((event.dataTransfer && event.dataTransfer.files) || []);
        if (files.length && $("menu")) start({ files });
    });
    $("exportSaves").addEventListener("click", doExport);
    $("importSaves").addEventListener("change", (event) => {
        const file = event.target.files[0];
        event.target.value = "";
        if (file) doImport(file);
    });
    $("clearCache").addEventListener("click", clearCache);
    $("advanced").addEventListener("toggle", () => $("advanced").open && showStorage());
}

async function main() {
    wireInputs();
    restoreOptions();
    if (!checkCapabilities()) return;
    await Promise.all([loadManifest(), setupServiceWorker()]);
    populateSystems();
    renderRecent();
    if (params.get("core")) $("system").value = params.get("core");
    const rom = params.get("rom");
    if (rom) {
        start({ rom: "roms/" + rom.replace(/^\/+/, ""), name: rom.split("/").pop() });
    }
}

main();
