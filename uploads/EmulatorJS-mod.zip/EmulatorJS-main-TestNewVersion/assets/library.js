// Recent-games library: metadata in localStorage, ROM bytes in IndexedDB so games relaunch with one click.
const RECENT_KEY = "ejs-recent";
const PLAYTIME_KEY = "ejs-playtime";
const DB_NAME = "EJS-library";
const STORE = "roms";
const MAX_ENTRIES = 12;
const MAX_STORED_BYTES = 512 * 1024 * 1024;

let dbPromise = null;
function db() {
    if (!window.indexedDB) return Promise.resolve(null);
    if (!dbPromise) {
        dbPromise = new Promise((resolve) => {
            const request = indexedDB.open(DB_NAME, 1);
            request.onupgradeneeded = () => request.result.createObjectStore(STORE);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => resolve(null);
        });
    }
    return dbPromise;
}
async function tx(mode, run) {
    const database = await db();
    if (!database) return undefined;
    return new Promise((resolve) => {
        const transaction = database.transaction(STORE, mode);
        const request = run(transaction.objectStore(STORE));
        transaction.oncomplete = () => resolve(request && request.result);
        transaction.onerror = transaction.onabort = () => resolve(undefined);
    });
}

export function listRecent() {
    try { return JSON.parse(localStorage.getItem(RECENT_KEY) || "[]"); } catch (e) { return []; }
}
function saveRecent(list) {
    try { localStorage.setItem(RECENT_KEY, JSON.stringify(list)); } catch (e) { /* storage unavailable */ }
}
export function playtimeFor(gameName) {
    try { return JSON.parse(localStorage.getItem(PLAYTIME_KEY) || "{}")[gameName] || 0; } catch (e) { return 0; }
}

/** Records a launch. Files are stored so they can be reopened; URLs are stored as references. */
export async function remember({ rom, name, system }) {
    const isFile = rom instanceof Blob;
    const id = isFile ? name + "|" + rom.size : "url|" + rom;
    let list = listRecent().filter((e) => e.id !== id);
    let stored = false;
    if (isFile && rom.size <= MAX_STORED_BYTES) {
        stored = (await tx("readwrite", (s) => s.put(rom, id))) !== undefined;
    }
    list.unshift({ id, name, system, size: isFile ? rom.size : 0, url: isFile ? null : rom, stored, lastPlayed: Date.now() });
    for (const old of list.slice(MAX_ENTRIES)) await tx("readwrite", (s) => s.delete(old.id));
    list = list.slice(0, MAX_ENTRIES);
    saveRecent(list);
}

export async function forget(id) {
    saveRecent(listRecent().filter((e) => e.id !== id));
    await tx("readwrite", (s) => s.delete(id));
}

/** Returns a File (or URL string) for a library entry, or null if its bytes are gone. */
export async function open(entry) {
    if (entry.url) return entry.url;
    const blob = await tx("readonly", (s) => s.get(entry.id));
    return blob ? new File([blob], entry.name) : null;
}

export function timeAgo(time) {
    const minutes = Math.round((Date.now() - time) / 60000);
    if (minutes < 1) return "just now";
    if (minutes < 60) return minutes + " min ago";
    if (minutes < 1440) return Math.round(minutes / 60) + " h ago";
    return Math.round(minutes / 1440) + " days ago";
}
export function formatPlaytime(seconds) {
    if (seconds < 60) return "";
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return h ? `${h} h ${m} min played` : `${m} min played`;
}
