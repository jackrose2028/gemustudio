# EmulatorJS (local build)

A self-contained copy of [EmulatorJS](https://github.com/EmulatorJS/EmulatorJS) that runs from local files only:
no CDN, no external requests, ready for GitHub Pages.

## Quick start

1. Copy your core archives (`*.7z`, unchanged) into `data/cores/`.
2. Refresh the core list: `node tools/generate-core-manifest.mjs`
   (a `manifest.json` for the 187 archives supplied with this project is already included).
3. Serve the folder with any static server, e.g. `python3 serve.py 8000`, and open `http://localhost:8000`.

Opening `index.html` straight from disk (`file://`) does not work: browsers block ES modules there.

## Publish on GitHub Pages

1. Commit everything, including `data/cores/*.7z` (largest archive is about 8 MB; the whole set is about 284 MB).
2. In the repository: **Settings -> Pages -> Deploy from a branch -> `main` / root**.
3. Open `https://<user>.github.io/<repo>/`.

All paths are relative, so it works in a sub-folder. `.nojekyll` is included so GitHub serves every file as-is.

## Using it

- Drop a ROM on the page or click the box. You can drop a BIOS and an IPS/BPS/UPS patch together with it.
- The system is found from the extension, the file header, or the names inside a zip; you are only asked
  when it is still unclear. Only systems whose cores are present in `data/cores/` are offered.
- Recent games appear on the menu for one-click play. Files never leave the device.
- In game, press **F1** for hotkeys and options: F2 save, F4 load, F3 slot, F5 pause, F6 fast forward,
  F8 screenshot, F9 mute, F10 FPS, F11 fullscreen. On a controller, hold Select and press R1/L1/R2/L2/Start.
- Leaving a game saves a resume point; next time you are offered to continue from it.
- **Options -> Export backup** saves all in-game saves, save states and settings to one file; import it on
  another browser or device.
- URL options: `?rom=game.nes` (loads `roms/game.nes`), `&core=nes`, `&threads=1`, `&debug=1`,
  `&cache=0`, `&browserMode=mobile|desktop`, `&lang=es`.

## Threads on GitHub Pages

Threaded cores (PSP and DOS need them, others run faster with them) require `SharedArrayBuffer`, which needs
two response headers GitHub Pages cannot send. `sw.js` adds them on the first visit: the page reloads once,
then **Options -> Threads** is available. This needs https (or `localhost`).

The service worker also caches the app and recently used cores so repeat visits and offline use are fast.
If you change files in `data/` or `assets/`, bump `VERSION` in `sw.js` so visitors pick the change up at once.

## Cores

Core archives are used exactly as built: `<core>[-thread][-legacy]-wasm.7z`. The loader picks the best
variant that exists (threaded if enabled, WebGL2 or legacy WebGL1) and falls back to a variant that is present.
Run `node tools/generate-core-manifest.mjs` whenever cores are added, removed or updated; the file sizes in the
manifest are used as cache-busting versions.

## Optional: minified build

`npm install && npm run minify` writes `data/emulator.min.js` and `.css`. Set `window.EJS_useMinified = true`
before loading `data/loader.js` to use them.

## License

EmulatorJS is licensed under GPL-3.0 (see `LICENSE`). Keep that file and the license notices when you publish
a copy. Cores are built from other projects under their own licenses (each archive contains `license.txt`).
Only host ROMs and BIOS files you have the right to share.
